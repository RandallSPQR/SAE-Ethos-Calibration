#!/usr/bin/env python3
"""Activation verbalizer (the 'watcher'). Three interchangeable backends; all return the same shape,
so analysis treats them uniformly and the card's epistemic caveat (AVs may confabulate) applies to all.

Backends:
  karvonen : the pretrained Gemma-2-9b-it oracle LoRA (same model reading its own activations)
  harp     : retrieval agent over the activation store (SriramB-98/HARP)
  patchscopes : zero-training self-explanation (patch activation into a placeholder prompt)
# STUB bodies; signatures final.
"""
from pathlib import Path
import yaml

CFG = Path(__file__).resolve().parent.parent / "config"


def load_oracle(backend="karvonen"):
    models = yaml.safe_load((CFG / "models.yaml").read_text())
    if backend == "karvonen":
        oid = models["oracle"]["hf_id"]
        raise NotImplementedError(
            f"STUB: PeftModel.from_pretrained(base_gemma_2_9b_it, '{oid}'); inject activations at the "
            f"oracle's placeholder tokens (depths {models['oracle']['depths']}).")
    if backend == "harp":
        raise NotImplementedError("STUB: build/query the HARP Milvus index at layer 32 (see arm-agnostic build).")
    if backend == "patchscopes":
        raise NotImplementedError("STUB: patch residual into 'The concept here is ___' on the same model.")
    raise ValueError(backend)


def verbalize(oracle, residual, positions):
    """Return [{'position': int, 'explanation': str, 'source': backend}] for the given positions. # STUB"""
    raise NotImplementedError("STUB verbalize: one natural-language explanation per requested position.")


def confabulation_probe(oracle):
    """Feed zeroed and shuffled activations; return the rate of confident, specific explanations.
    Feeds G5's confab_rate. # STUB"""
    raise NotImplementedError("STUB: run verbalize on null activations; score specificity/confidence.")
