#!/usr/bin/env python3
"""Attach the Gemma Scope SAE via SAELens and encode residuals to sparse features. # STUB bodies.

The SAE is the store of record for features. Neuronpedia labels are pulled once into
features/feature_labels.json (replaces the card's 'top-activating dataset examples' panels for free).
"""
from pathlib import Path
import numpy as np
import yaml

CFG = Path(__file__).resolve().parent.parent / "config"


def load_sae():
    """# STUB: from sae_lens import SAE; SAE.from_pretrained_with_cfg(release, sae_id).
    Uses the EXACT canonical artifact from models.yaml (release + sae_id), not a layer int."""
    models = yaml.safe_load((CFG / "models.yaml").read_text())
    s = models["sae"]
    raise NotImplementedError(
        f"STUB load_sae: SAE.from_pretrained('{s['release']}', '{s['sae_id']}'). "
        f"Confirm sae.cfg.hook_name == '{s['saelens_hook_name']}' after load — that string is the "
        f"contract between the SAE and your residual capture.")


def encode(sae, residual: "np.ndarray"):
    """residual [seq, d_model] -> sparse feature activations. Returns list of (pos, feature, act) for
    nonzero post-ReLU activations. # STUB (real: sae.encode(torch.tensor(residual)))."""
    raise NotImplementedError("STUB encode: return nonzero (position, feature_index, activation) triples.")


def sae_health(sae, residual: "np.ndarray"):
    """Variance-explained and mean L0 for a batch of residuals at ONE hook. # STUB

    L0 IS THE NUMBER OF ACTIVE FEATURES PER TOKEN, then averaged over tokens:
        l0 = (feature_acts > 0).sum(dim=-1).float().mean()      # ~60 for 16k canonical
    NOT `(enc > 0).float().mean()`, which is activation DENSITY (~60/16384 ≈ 0.0037) — a silent bug that
    would make G2's L0 never match Google's published value.

    Prefer SAELens's OWN evaluator for both L0 and explained variance rather than hand-rolling
    `1 - mse/var` — use the same metric implementation that produced the published number, so G2 is a
    true replication, not an approximation (SAELens computes total variance across samples carefully and
    distinguishes the legacy definition)."""
    raise NotImplementedError(
        "STUB sae_health: use SAELens's evaluator; L0 = (acts>0).sum(dim=-1).float().mean(), "
        "explained variance via SAELens (not a casual 1-mse/var). Return {'var_explained','l0'}.")


def hook_identification_report(lm, sae, residuals_by_hook):
    """Compute health at the CHOSEN hook AND at each decoy candidate, and emit the JSON G2 consumes.
    This is the guard against attaching the SAE to a same-shape-but-wrong tensor. # STUB
    residuals_by_hook: {hook_path: np.ndarray[seq,d_model]} captured in one pass over calibration text.
    Writes features/sae_health.json = {chosen, candidates[], published(from models.yaml)}."""
    import yaml as _yaml
    models = _yaml.safe_load((CFG / "models.yaml").read_text())["sae"]
    raise NotImplementedError(
        "STUB: for models.yaml sae.hook_point AND each sae.hook_candidates, run sae_health on its "
        "residuals; write {chosen, candidates, published: models.sae.published}. Only the trained hook "
        "should reproduce Google's FVU/L0.")


def fetch_neuronpedia_labels(feature_indices, out_path):
    """Pull labels for the given features into feature_labels.json. Network step, not GPU. # STUB
    Uses the public Neuronpedia API for the configured Gemma Scope release."""
    raise NotImplementedError("STUB: GET neuronpedia feature pages for the release; write {idx: {label,...}}.")
