#!/usr/bin/env python3
"""Teacher-forcing + activation capture + steering injection. # STUB bodies; signatures final.

These three operations share one forward pass abstraction so G1 (fidelity), replay (capture), and
G4/steer (injection) all go through the same code path — if they diverged, a fidelity pass could
validate a path the real run doesn't use.
"""
from dataclasses import dataclass
import numpy as np


@dataclass
class ForwardResult:
    token_ids: list          # input ids (teacher-forced)
    logits_argmax: list      # argmax at each position (G0/G1 exact-replay checksum)
    input_logprobs: list     # logprob of each input id under the forward (T>0 fidelity criterion)
    residual: "np.ndarray"   # [seq, d_model] at the VERIFIED hook_resid_post
    assistant_span: tuple    # [start, end)


def build_input_ids(lm, messages, upto=None):
    """Token ids for replay via the ONE canonical serializer (model_io.gemma2.apply_to_tokenizer) — the
    SAME function generation uses, so replay teacher-forces exactly what the model saw. Returns ids and
    the assistant_span of the last assistant (model) turn. This shared path is what G1 validates. # STUB
    box-side: from model_io.gemma2 import apply_to_tokenizer;
              ids = apply_to_tokenizer(lm.tokenizer, messages[:upto], add_generation_prompt=False);
              assistant_span = token offsets of the final model turn (serialize the prefix without the
              last turn, tokenize, and take len(prefix_ids)..len(full_ids))."""
    raise NotImplementedError(
        "STUB build_input_ids: use model_io.gemma2.apply_to_tokenizer (the shared serializer). Compute "
        "assistant_span by diffing token length with/without the final model turn.")


def resid_post(layer_output):
    """Reconstruct hook_resid_post from a Gemma-2 decoder layer's output.

    A Gemma-2 decoder block returns (hidden_states, residual) (or similar), and the residual stream
    LEAVING the block is their SUM — hook_resid_post is NOT `layer.output[0]` alone. That naive read is
    a G2 decoy candidate for a reason. Establish the exact transform empirically during calibration and
    lock it here; validate by reproducing the canonical SAE's FVU/L0. # STUB"""
    raise NotImplementedError(
        "STUB resid_post: at calibration, determine which combination of the block's output tuple equals "
        "SAELens 'blocks.31.hook_resid_post', then return it. Do NOT assume output[0].")


def teacher_forced_forward(lm, messages, capture_residual=True, steer=None):
    """One forward over the teacher-forced sequence. Captures the residual via resid_post() at the
    verified hook (never a bare output[0]). If steer=(vector, strength), add
    strength * mean_residual_norm * unit(vector) at every position before it flows onward. Also returns
    per-position logprobs of the input ids (used by the T>0 fidelity criterion). Returns ForwardResult.
    # STUB"""
    raise NotImplementedError(
        "STUB: with lm.model.trace(input_ids): residual = resid_post(block.output).save(); "
        "if steer: add scaled vector in-place; capture logits.argmax(-1) AND logprob of each input id.")


def sampled_ids_from_transcript(row):
    """The ids the target actually emitted for the scored assistant turn (from generation).
    Populated by replay from row['tokens']['sampled_ids']; used only by G1."""
    return (row.get("tokens") or {}).get("sampled_ids")
