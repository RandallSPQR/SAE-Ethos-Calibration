#!/usr/bin/env python3
"""Load the target model under nnsight for teacher-forced replay. # STUB bodies; signatures are final.

nnsight is preferred over TransformerLens at 9B+ (memory + architecture coverage). The same HF weights
that vLLM serves for generation are loaded here for white-box access — one model, two views.
"""
from dataclasses import dataclass
from pathlib import Path
import yaml

CFG = Path(__file__).resolve().parent.parent / "config"


@dataclass
class LoadedModel:
    model: object          # nnsight.LanguageModel
    tokenizer: object
    n_layers: int
    d_model: int
    layer: int             # resolved SAE/hook layer


def resolve_layer(n_layers, fraction):
    return max(0, min(n_layers - 1, round(n_layers * fraction)))


def load_target(which="target"):
    """which: 'target' (IT model) or 'base' (pretrained, for §4.5.3.4). # STUB

    Preferred backend: nnsight's vLLM backend runs the intervention INSIDE the vLLM worker, so we keep
    PagedAttention / continuous batching / TP and do NOT load a second Transformers copy just to inspect.
    One served model, intervened in place. (Fall back to nnsight.LanguageModel over HF weights only if
    the vLLM backend can't attach for this arch.)"""
    models = yaml.safe_load((CFG / "models.yaml").read_text())
    hf_id = models["target_model"]["hf_id" if which == "target" else "base_hf_id"]
    raise NotImplementedError(
        f"STUB load_target({which}): use nnsight's vLLM backend against the running server for '{hf_id}' "
        f"so intervention happens in the worker; resolve the hook from models.yaml sae.hook_point "
        f"(NOT a bare layer index).")


def residual_module(lm: LoadedModel, hook_point=None):
    """Return the nnsight handle for the EXACT trained residual tensor named by sae.hook_point. # STUB
    Never a bare `layers[i]` — G2 will reject an unverified hook, but attach the right one to begin with."""
    raise NotImplementedError("STUB: resolve models.yaml sae.hook_point to the nnsight module handle.")
